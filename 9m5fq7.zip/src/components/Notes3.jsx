import React from "react";

function Notes3() {
  return (
    <div className="note">
      <h1> Note 3:</h1>
      <p>
        Advanced Editor Features of NotePad Online Word Count: Our online
        textpad (notebook) allows you to check the total number of words written
      </p>
    </div>
  );
}

export default Notes3;
