import React from "react";

function Notes7() {
  return (
    <div className="note">
      <h1> Note 7:</h1>
      <p>
        Uses of Editpad Online: The most common uses of our online NotePad are:
        It helps to write and edit the text in no time. Students and other users
        can quickly create online notes without installing text editing
        software. Allows you to check the originality of written content
      </p>
    </div>
  );
}

export default Notes7;
