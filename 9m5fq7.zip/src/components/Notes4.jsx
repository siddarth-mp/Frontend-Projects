import React from "react";

function Notes4() {
  return (
    <div className="note">
      <h1> Note 4:</h1>
      <p>
        Character Count: You can also check the exact number of characters in
        your writing by using this feature. It will promptly count characters.
      </p>
    </div>
  );
}

export default Notes4;
