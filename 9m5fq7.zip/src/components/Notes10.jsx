import React from "react";

function Notes10() {
  return (
    <div className="note">
      <h1> Note 10:</h1>
      <p>
        Features of Plagiarism Checker It has a simple interface and free to
        use. Other features of plagiarism detector are: File Support: Upload
        files directly from the computer in the following formats: DOC DOCX TXT
      </p>
    </div>
  );
}

export default Notes10;
