import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import Notes from "./Notes";
import Notes2 from "./Notes2";
import Notes3 from "./Notes3";
import Notes4 from "./Notes4";
import Notes5 from "./Notes5";
import Notes6 from "./Notes6";
import Notes7 from "./Notes7";
import Notes8 from "./Notes8";
import Notes9 from "./Notes9";
import Notes10 from "./Notes10";

function App() {
  return (
    <div>
      <Header />
      <Notes />
      <Notes2 />
      <Notes3 />
      <Notes4 />
      <Notes5 />
      <Notes6 />
      <Notes7 />
      <Notes8 />
      <Notes9 />
      <Notes10 />
      <Footer />
    </div>
  );
}

export default App;
