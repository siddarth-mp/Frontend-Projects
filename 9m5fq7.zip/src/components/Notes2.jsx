import React from "react";

function Notes2() {
  return (
    <div className="note">
      <h1> Note 2:</h1>
      <p>
        Open Editpad Wordpad and start creating the notes online. You can also
        copy-paste to edit text and save it for later use. Besides this, our
        online notepad
      </p>
    </div>
  );
}

export default Notes2;
