import React from "react";

function Notes() {
  return (
    <div className="note">
      <h1> This is React bootcamp</h1>
      <p>
        Notes is a notetaking app developed by Apple. It is provided on their
        iOS and macOS operating systems, the latter starting with OS X Mountain
        Lion
      </p>
    </div>
  );
}

export default Notes;
