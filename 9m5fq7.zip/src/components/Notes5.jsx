import React from "react";

function Notes5() {
  return (
    <div className="note">
      <h1> Note 5:</h1>
      <p>
        No Installation: The best thing about Plain Text Editor is that you
        don’t need to install it to complete your tasks. Converts Rich Text:
        Remove text formatting in word, excel & g-docs.
      </p>
    </div>
  );
}

export default Notes5;
