import React from "react";

function Notes9() {
  return (
    <div className="note">
      <h1> Note 9:</h1>
      <p>
        How does our Plagiarism Checker work? Plagiarism checker scans your
        content and compares it with online databases and published content on
        the internet to find plagiarism. How to use this tool? To use plagiarism
        checker:
      </p>
    </div>
  );
}

export default Notes9;
