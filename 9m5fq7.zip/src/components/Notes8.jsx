import React from "react";

function Notes8() {
  return (
    <div className="note">
      <h1> Note 8:</h1>
      <p>
        Plagiarism Checker is a free online tool to check plagiarism in text.
        Find duplicate content, add sources of non-quoted text and download
        plagiarism report for freelance writing, Plagiarism is “using another
        person’s words, ideas, or thoughts as your own”
      </p>
    </div>
  );
}

export default Notes8;
