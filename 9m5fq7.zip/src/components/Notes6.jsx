import React from "react";

function Notes6() {
  return (
    <div className="note">
      <h1> Note 6:</h1>
      <p>
        Check Plagiarism and Grammar: You can also check plagiarism and grammar
        of edited text in our online editor. Paraphrase Text: If you’re writing
        plain text in our online Notepad, you also have an option to paraphrase
        & summarize it in the same typing pad.
      </p>
    </div>
  );
}

export default Notes6;
